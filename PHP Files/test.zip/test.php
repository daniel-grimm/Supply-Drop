<?php   
$user_name = "kodite";  
$password = "#2Twinkie";  
$database = "supply-drop";  
$server = "supply-drop.cdkcwqlnuxlm.us-west-2.rds.amazonaws.com";  
$db_handle = mysql_connect($server, $user_name, $password);
$db_found = mysql_select_db($database, $db_handle);  
if($db_handle)    
{         
    print "Connected";  
}  
else  
{  
    print "Can not connect to server";  
}         
if ($db_found)   
{ 
     print "DataBase found";  
}  
else   
{  
    print "DataBase not found";  
}  
?>